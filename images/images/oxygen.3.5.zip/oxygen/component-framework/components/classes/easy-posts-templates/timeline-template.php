<div class="oxy-timeline-block">
    <div class="oxy-timeline-marker">
    </div>
    <div class="oxy-timeline-content">
        <a class='oxy-post-title' href='<?php the_permalink(); ?>'><?php the_title(); ?></a>

        <div class='oxy-post-content'>
            <?php the_excerpt(); ?>
        </div>
    </div>
</div>
